create
    definer = quintom@localhost procedure sp_listar_palabras()
begin
    select 
        codigo_palabra,
        nombre,
        pista_1,
        pista_2,
        pista_3
    from palabras;
end;

